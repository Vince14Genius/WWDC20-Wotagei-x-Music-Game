import SpriteKit
import GameSceneBoilerplate
import WotageiChart

public class WotageiGame {
    public let view: SKView
    
    public init(chart: ChartTable) {
        view = GameView(gsDelegate: GameDelegate(chart: chart)).skView
    }
}
