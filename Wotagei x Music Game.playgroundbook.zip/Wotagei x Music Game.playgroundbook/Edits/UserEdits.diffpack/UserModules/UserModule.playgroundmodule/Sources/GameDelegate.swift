import GameSceneBoilerplate
import JoystickKit
import WotageiPlayer
import WotageiChart
import WotageiChartPlayer
import WotageiShared

public class GameDelegate: NSObject, GameSceneDelegate {
    private var joysticks = [Joystick]()
    private var chartPlayer: ChartPlayer!
    private let chart: ChartTable
    
    public init(chart: ChartTable) {
        self.chart = chart
        super.init()
    }
    
    public func initialize(scene: SKScene) {
        scene.scaleMode = .aspectFill
        scene.backgroundColor = .black
        let sceneCenter = CGPoint(
            dx: GameScene.halfSceneLength, 
            dy: GameScene.halfSceneLength
        )
        
        // Set up Uchishi
        let uchishi = Uchishi(parent: scene, position: sceneCenter)
        
        // Set up left joystick
        joysticks.append(Joystick(
            side: .left, 
            parent: scene, 
            frame: CGRect(x: 0, y: 0, width: GameScene.halfSceneLength, height: 2 * GameScene.halfSceneLength), 
            color: WotageiSettings.leftGlowstickColor
        ))
        
        // Set up right joystick
        joysticks.append(Joystick(
            side: .right, 
            parent: scene, 
            frame: CGRect(x: GameScene.halfSceneLength, y: 0, width: GameScene.halfSceneLength, height: 2 * GameScene.halfSceneLength), 
            color: WotageiSettings.rightGlowstickColor
        ))
        
        // Set up ChartPlayer
        chartPlayer = ChartPlayer(
            chart: chart, 
            parent: scene, 
            position: sceneCenter
        )
        
        // Pair Uchishi and ChartPlayer with joysticks
        joysticks.map {
            $0.addDelegate(uchishi)
            $0.addDelegate(chartPlayer)
        }
    }
    
    public func update(_ currentTime: TimeInterval, for scene: SKScene) {
        chartPlayer.update(currentTime: currentTime)
        joysticks.map { $0.update() }
    }
    
    public func touchBegan(touch: UITouch) {
        joysticks.map { $0.touchBegan(touch: touch) }
    }
    
    public func touchMoved(touch: UITouch) {
        joysticks.map { $0.touchMoved(touch: touch) }
    }
    
    public func touchEnded(touch: UITouch) {
        joysticks.map { $0.touchEndedOrCancelled(touch: touch) }
    }
    
    public func touchCancelled(touch: UITouch) {
        joysticks.map { $0.touchEndedOrCancelled(touch: touch) }
    }
}
