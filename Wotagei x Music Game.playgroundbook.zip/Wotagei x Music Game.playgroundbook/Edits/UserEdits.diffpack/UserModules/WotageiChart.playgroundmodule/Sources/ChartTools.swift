import GameMathKit

public typealias CT = ChartTools

public struct ChartTools {
    public static func rad(_ deg: Double) -> Double {
        return radians(deg)
    }
}
