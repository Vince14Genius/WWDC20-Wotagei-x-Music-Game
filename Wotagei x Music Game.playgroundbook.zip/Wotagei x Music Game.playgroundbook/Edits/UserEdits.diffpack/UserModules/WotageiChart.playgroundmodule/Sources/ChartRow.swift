import Foundation
@_exported import SideKit
import WotageiShared

/**
 A standard row of `ChartTable`
 */
public typealias ChartRow = (
    beatID: Double, 
    side: Side, 
    magnitude: Double, 
    direction: Double, 
    glowstickDirection: Double?
)
