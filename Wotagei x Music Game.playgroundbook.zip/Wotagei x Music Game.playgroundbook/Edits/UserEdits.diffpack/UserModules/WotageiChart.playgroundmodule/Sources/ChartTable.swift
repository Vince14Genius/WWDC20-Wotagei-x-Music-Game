import Foundation
import WotageiShared

/**
 A collection of `ChartRow`, automatically sorted
 */
public struct ChartTable {
    let rows: [ChartRow]
    
    /**
     Automatically sorts
     */
    public init(_ rows: [ChartRow]) {
        self.rows = rows.sorted { return $0.beatID < $1.beatID }
    }
    
    public func findRows(timeRange: Range<TimeInterval>) -> [ChartRow] {
        return rows.filter { return timeRange.contains(WotageiConstants.time(from: $0.beatID)) }
    }
}

