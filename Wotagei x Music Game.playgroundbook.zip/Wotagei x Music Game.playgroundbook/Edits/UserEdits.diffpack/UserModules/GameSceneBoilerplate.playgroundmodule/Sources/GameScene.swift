import SpriteKit

public class GameScene: SKScene {
    public static let halfSceneLength = 500.0
    public static var sceneLength: Double { return halfSceneLength * 2 }
    public static var sceneSize: CGSize { return CGSize(width: sceneLength, height: sceneLength) }
    public let gsDelegate: GameSceneDelegate
    
    public init(gsDelegate: GameSceneDelegate) {
        self.gsDelegate = gsDelegate
        super.init(size: CGSize(width: GameScene.halfSceneLength * 2, height: GameScene.halfSceneLength * 2))
        self.delegate = delegate
        gsDelegate.initialize(scene: self)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func update(_ currentTime: TimeInterval) {
        gsDelegate.update?(currentTime, for: self)
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        touches.map { gsDelegate.touchBegan(touch: $0) }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        touches.map { gsDelegate.touchMoved(touch: $0) }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        touches.map { gsDelegate.touchEnded(touch: $0) }
    }
    
    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        touches.map { gsDelegate.touchCancelled(touch: $0) }
    }
}
