import SpriteKit

public class GameView {
    public let skView = SKView()
    
    public init(gsDelegate: GameSceneDelegate) {
        skView.ignoresSiblingOrder = true
        skView.isMultipleTouchEnabled = true
        skView.presentScene(GameScene(gsDelegate: gsDelegate))
    }
}
