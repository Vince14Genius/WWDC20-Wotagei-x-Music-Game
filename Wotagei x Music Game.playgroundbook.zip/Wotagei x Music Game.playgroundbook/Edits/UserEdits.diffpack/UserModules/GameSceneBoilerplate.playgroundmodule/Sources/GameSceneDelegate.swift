import SpriteKit

public protocol GameSceneDelegate: SKSceneDelegate {
    func initialize(scene: SKScene)
    func touchBegan(touch: UITouch)
    func touchMoved(touch: UITouch)
    func touchEnded(touch: UITouch)
    func touchCancelled(touch: UITouch)
}
