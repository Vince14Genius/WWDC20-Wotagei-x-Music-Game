
import UIKit

extension UIColor {
    public var red: CGFloat? {
        var r: CGFloat = 0.0
        if self.getRed(&r, green: nil, blue: nil, alpha: nil) {
            return r
        }
        return nil
    }
    
    public var green: CGFloat? {
        var g: CGFloat = 0.0
        if self.getRed(nil, green: &g, blue: nil, alpha: nil) {
            return g
        }
        return nil
    }
    
    public var blue: CGFloat? {
        var b: CGFloat = 0.0
        if self.getRed(nil, green: nil, blue: &b, alpha: nil) {
            return b
        }
        return nil
    }
    
    public var alpha: CGFloat? {
        var a: CGFloat = 0.0
        if self.getRed(nil, green: nil, blue: nil, alpha: &a) {
            return a
        }
        return nil
    }
    
    public func modifiedBy(dr: CGFloat, dg: CGFloat, db: CGFloat, da: CGFloat) -> UIColor? {
        guard let r = self.red else { return nil }
        guard let g = self.green else { return nil }
        guard let b = self.blue else { return nil }
        guard let a = self.alpha else { return nil }
        
        return UIColor(red: r + dr, green: g + dg, blue: b + db, alpha: a + da)
    }
    
    public func modifiedTo(r: CGFloat?, g: CGFloat?, b: CGFloat?, a: CGFloat?) -> UIColor? {
        guard let red = self.red else { return nil }
        guard let green = self.green else { return nil }
        guard let blue = self.blue else { return nil }
        guard let alpha = self.alpha else { return nil }
        
        return UIColor(
            red: r != nil ? r! : red,
            green: g != nil ? g! : green, 
            blue: b != nil ? b! : blue, 
            alpha: a != nil ? a! : alpha
        )
    }
}
