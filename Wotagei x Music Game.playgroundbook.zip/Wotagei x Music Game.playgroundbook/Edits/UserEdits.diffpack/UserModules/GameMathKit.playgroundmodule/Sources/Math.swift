@_exported import CoreGraphics

public protocol CGVectorRepresentable {
    var dx: Double { get }
    var dy: Double { get }
    init(dx: Double, dy: Double)
    init<T: CGVectorRepresentable>(_ vectorRepresentable: T)
}

public func +<T: CGVectorRepresentable>(_ lhs: T, _ rhs: T) -> T {
    return T(dx: lhs.dx + rhs.dx, dy: lhs.dy + rhs.dy)
}

public func -<T: CGVectorRepresentable>(_ lhs: T, _ rhs: T) -> T {
    return T(dx: lhs.dx - rhs.dx, dy: lhs.dy - rhs.dy)
}

public func *<T: CGVectorRepresentable>(_ lhs: T, _ rhs: Double) -> T {
    return T(dx: lhs.dx * rhs, dy: lhs.dy * rhs)
}

public func abs<T: CGVectorRepresentable>(_ vector: T) -> Double {
    return sqrt(pow(vector.dx, 2) + pow(vector.dy, 2))
}

public func atan2<T: CGVectorRepresentable>(_ vector: T) -> Double {
    return atan2(vector.dy, vector.dx)
}

public func vectorized(magnitude: Double, direction: Double) -> CGVector {
    return CGVector(dx: magnitude * cos(direction), dy: magnitude * sin(direction))
}

public func pointified(magnitude: Double, direction: Double) -> CGPoint {
    return CGPoint(x: magnitude * cos(direction), y: magnitude * sin(direction))
}

public func radians(_ deg: Double) -> Double {
    return deg * .pi / 180
}

extension CGVector: CGVectorRepresentable {
    public var dx: Double { return Double(dx) }
    public var dy: Double { return Double(dy) }
    public init<T: CGVectorRepresentable>(_ vectorRepresentable: T) {
        self.init(dx: vectorRepresentable.dx, dy: vectorRepresentable.dy)
    }
}

extension CGPoint: CGVectorRepresentable {
    public var dx: Double { return Double(x) }
    public var dy: Double { return Double(y) }
    public init(dx: Double, dy: Double) {
        self.init(x: dx, y: dy)
    }
    public init<T>(_ vectorRepresentable: T) where T : CGVectorRepresentable {
        self.init(x: vectorRepresentable.dx, y: vectorRepresentable.dy)
    }
}
