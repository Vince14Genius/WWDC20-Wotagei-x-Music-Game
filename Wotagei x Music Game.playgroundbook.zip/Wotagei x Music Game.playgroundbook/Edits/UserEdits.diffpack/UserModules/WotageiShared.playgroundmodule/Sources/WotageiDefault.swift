import UIKit

public struct WotageiDefault {
    public static let leftDefaultColor = #colorLiteral(red: 0.10196078431372549, green: 0.2784313725490196, blue: 0.4, alpha: 1.0)
    public static let rightDefaultColor = #colorLiteral(red: 0.5215686274509804, green: 0.10980392156862745, blue: 0.050980392156862744, alpha: 1.0)
    public static let proDefaultColor = #colorLiteral(red: 0.5, green: 0.16, blue: 0.05, alpha: 1.0)
}
