import CoreGraphics
import Foundation

public struct WotageiConstants {
    public static let startingWait: TimeInterval = 4.0
    public static let wingspan = 350.0
    
    public static let backLightingZ: CGFloat = -100
    public static let silhouetteZ: CGFloat = -10
    public static let nodeZ: CGFloat = 10
    public static let glowstickZ: CGFloat = 200
    public static let overlayZ: CGFloat = 300
    
    public static var timePerBeat: TimeInterval {
        let raw = 60 / WotageiSettings.bpm
        switch WotageiSettings.difficulty {
            case .easy:
                return raw * 3
            case .medium:
                return raw * 2
            case .hard:
                return raw
        }
    }
    
    public static func time(from beats: Double) -> TimeInterval {
        return beats * Self.timePerBeat
    }
}
