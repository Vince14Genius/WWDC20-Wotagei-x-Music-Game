import UIKit
import SideKit

public enum Difficulty: Int {
    case easy = 1, medium, hard
}

public struct WotageiSettings {
    public static var bpm: Double = 150
    
    public static var isMirrored = false
    public static var difficulty = Difficulty.easy
    
    public static var leftGlowstickColor = WotageiDefault.leftDefaultColor
    public static var rightGlowstickColor = WotageiDefault.rightDefaultColor
    
    public static func glowstickColor(side: Side) -> UIColor {
        switch side {
        case .left:
            return WotageiSettings.leftGlowstickColor 
        case .right:
            return WotageiSettings.rightGlowstickColor 
        }
    }
}
