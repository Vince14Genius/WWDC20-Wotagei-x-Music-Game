import SpriteKit

public extension SKEmitterNode {
    public static func copy(_ node: SKEmitterNode?) -> SKEmitterNode? {
        return node?.copy() as? SKEmitterNode
    }
}

