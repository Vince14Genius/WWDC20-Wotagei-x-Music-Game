import SpriteKit
import SideKit
import GameMathKit
import WotageiShared
import WotageiChart

public class Silhouette {
    private let node = SKNode()
    
    private let legs: [Side: SilhouetteLeg]
    
    private var handLocations = [Side: CGPoint]()
    
    public init(parent: SKNode, wingspan: Double) {
        node.zPosition = WotageiConstants.silhouetteZ
        parent.addChild(node)
        legs = [
            .left: SilhouetteLeg(
                parent: node, 
                wingspan: wingspan,
                footLocationAngle: -133 
            ),
            .right: SilhouetteLeg(
                parent: node, 
                wingspan: wingspan,
                footLocationAngle: -47
            )
        ]
    }
    
    public func update(handLocation: CGPoint, side: Side) {
        handLocations[side] = handLocation
        
        legs.map { (_, value) in
            var sum = 0.0
            for (_, value) in handLocations { sum += value.dx }
            value.update(jointX: sum * 0.3 / Double(handLocations.count))
        }
    }
}

