import JoystickKit
import WotageiShared

public class Uchishi: JoystickInputDelegate {
    
    private var glowsticks = [Glowstick]()
    
    private let node = SKNode()
    private let glowstickLayer = SKNode()
    private let silhouette: Silhouette
    
    public init(parent: SKNode, position: CGPoint) {
        glowstickLayer.zPosition = WotageiConstants.glowstickZ
        parent.addChild(node)
        node.addChild(glowstickLayer)
        node.position = position
        
        // Set up Silhouette
        silhouette = Silhouette(parent: node, wingspan: WotageiConstants.wingspan)
        
        // Set up glowsticks
        
        func setupGlowstick(side: Side) {
            glowsticks.append(Glowstick(parent: glowstickLayer, side: side))
        }
        
        setupGlowstick(side: .left)
        setupGlowstick(side: .right)
        
        // Set up background lighting
        if let sceneSize = node.scene?.size {
            let backgroundDummySprite = SKSpriteNode(color: #colorLiteral(red: 0.07, green: 0.07, blue: 0.07, alpha: 1.0), size: sceneSize)
            backgroundDummySprite.zPosition = WotageiConstants.backLightingZ
            
            node.addChild(backgroundDummySprite)
            backgroundDummySprite.lightingBitMask = Glowstick.lightNodeBitMask
        }
    }
    
    public func joystickMoved(_ side: Side, newMagnitude: Double, newDirection: Double) {
        glowsticks.map {
            guard side == $0.side else { return }
            let point = $0.updateLocation(magnitude: newMagnitude, direction: newDirection)
            silhouette.update(handLocation: point, side: side)
        }
        
        // Mirror
        node.xScale = WotageiSettings.isMirrored ? -1 : 1
    }
    
    public func joystickEnded(_ side: Side) {
        glowsticks.map {
            guard side == $0.side else { return }
            $0.hide()
        }
    }
}
