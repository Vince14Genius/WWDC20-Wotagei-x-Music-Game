import SpriteKit
import GameMathKit
import SideKit
import WotageiShared

class Glowstick {
    public static let lightNodeBitMask: UInt32 = 0b10000
    
    private static let _emitter = SKEmitterNode(fileNamed: "glowstick")
    private static var emitter: SKEmitterNode? {
        return SKEmitterNode.copy(_emitter)
    }
    
    public let side: Side
    
    private let node = SKShapeNode(circleOfRadius: 4)
    private let lightNode = SKLightNode()
    
    private var activeEmitter: SKEmitterNode?
    
    public init(parent: SKNode, side: Side) {
        self.side = side
        parent.addChild(node)
        node.isHidden = true
        let color = WotageiSettings.glowstickColor(side: side)
        
        // Add light node
        node.addChild(lightNode)
        lightNode.isEnabled = true
        lightNode.categoryBitMask = Glowstick.lightNodeBitMask
        lightNode.ambientColor = color
        lightNode.lightColor = color
        lightNode.falloff = 0.1
        
        // Add emitter
        if let emitterCopy = Glowstick.emitter {
            emitterCopy.particleLifetime = CGFloat(WotageiConstants.timePerBeat) / 10
            activeEmitter = emitterCopy
            emitterCopy.particleColorSequence = nil // reset color
            emitterCopy.particleColor = color
            node.run(.sequence([
                .wait(forDuration: 0.001),
                .run {
                    self.node.addChild(emitterCopy)
                    emitterCopy.targetNode = parent
                }
            ]))
        }
        
        // Final setup
        hide()
    }
    
    public func hide() {
        node.isHidden = true
        activeEmitter?.resetSimulation()
        activeEmitter?.isPaused = true
    }
    
    /**
     Updates the `Glowstick`'s position and returns the new position.
     - Returns: the new position
     */
    public func updateLocation(magnitude: Double, direction: Double) -> CGPoint {
        node.isHidden = false
        node.position = pointified(magnitude: WotageiConstants.wingspan * magnitude, direction: direction)
        if activeEmitter?.isPaused ?? false {
            //activeEmitter?.resetSimulation()
        }
        activeEmitter?.isPaused = false
        return node.position
    }
    
}
