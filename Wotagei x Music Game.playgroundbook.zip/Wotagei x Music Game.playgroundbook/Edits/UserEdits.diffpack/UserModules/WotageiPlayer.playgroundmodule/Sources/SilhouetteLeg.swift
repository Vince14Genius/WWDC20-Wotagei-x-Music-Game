import SpriteKit
import GameMathKit

class SilhouetteLeg {
    public var legBoneLength: Double {
        return 0.8 * wingspan / 2
    }
    
    public var jointY: Double {
        return -0.16 * wingspan
    }
    
    public func jointLocation(x: Double) -> CGPoint {
        return CGPoint(x: x, y: jointY)
    }
    
    private let node = SKShapeNode()
    private let footLocation: CGPoint
    private let wingspan: Double
    
    public init(parent: SKNode, wingspan: Double, footLocationAngle: Double) {
        self.wingspan = wingspan
        parent.addChild(node)
        footLocation = pointified(magnitude: 0.9 * wingspan, direction: radians(footLocationAngle))
        node.strokeColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        node.lineWidth = CGFloat(abs(footLocation) / 8)
        
        let foot = SKShapeNode(circleOfRadius: 40)
        node.addChild(foot)
        foot.position = footLocation
        foot.fillColor = .black
        foot.strokeColor = #colorLiteral(red: 0.2549019607843137, green: 0.27450980392156865, blue: 0.30196078431372547, alpha: 1.0)
        foot.zPosition = -1
    }
    
    public func update(jointX: Double) {
        let jointLoc = jointLocation(x: jointX)
        let distance = abs(footLocation - jointLoc)
        guard distance <= legBoneLength * 2 else { return }
        
        let baseAngle = atan2(footLocation - jointLoc)
        // 2 * legBoneLength * cos(angle) = distance
        // cos(angle) = 0.5 * distance / legBoneLength
        let absAngle = acos(0.5 * distance / legBoneLength)
        let candidateA = baseAngle + absAngle
        let candidateB = baseAngle - absAngle
        let finalAngle: Double
        if (footLocation.x < 0) != (jointX < 0) || jointX == 0 {
            // case: different side or neutral position
            finalAngle = sin(candidateA) < sin(candidateB) ? candidateA : candidateB
        } else {
            // case: same side
            finalAngle = sin(candidateA) > sin(candidateB) ? candidateA : candidateB
        }
        let finalMidPoint = jointLoc + CGPoint(
            x: legBoneLength * cos(finalAngle),
            y: legBoneLength * sin(finalAngle)
        )
        
        let path = CGMutablePath()
        path.move(to: jointLoc)
        path.addLine(to: finalMidPoint)
        path.addLine(to: footLocation)
        
        node.path = path
    }
}
