
@_exported import SpriteKit
import GameMathKit
@_exported import SideKit

public class Joystick {
    private let maxDistanceMultiplier = 0.5
    
    private let base = SKShapeNode(circleOfRadius: 108)
    private let button = SKShapeNode(circleOfRadius: 30)
    
    private let parent: SKNode
    private let frame: CGRect
    
    private var activeTouch: UITouch?
    private var delegates = [JoystickInputDelegate]()
    
    public var side: Side
    
    public init(side: Side, parent: SKNode, frame: CGRect, color: UIColor) {
        self.side = side
        self.parent = parent
        self.frame = frame
        base.addChild(button)
        parent.addChild(base)
        button.fillColor = color
        button.strokeColor = .gray
        base.strokeColor = color
        base.zPosition = 1000
        button.zPosition = 1001
        base.alpha = 0
    }
    
    private func touchActive(touch: UITouch) {
        let touchPoint = touch.location(in: base)
        let direction = atan2(touchPoint)
        let distance = abs(touchPoint)
        let maxDistance = Double(base.frame.size.width) * maxDistanceMultiplier
        let magnitude = (distance < maxDistance) ? (distance / maxDistance) : 1
        button.position = pointified(magnitude: maxDistance * magnitude, direction: direction)
        delegates.map { $0.joystickMoved(side, newMagnitude: magnitude, newDirection: direction) }
    }
    
    public func addDelegate(_ delegate: JoystickInputDelegate) {
        delegates.append(delegate)
    }
    
    public func touchBegan(touch: UITouch) {
        guard activeTouch == nil && frame.contains(touch.location(in: parent)) else { return }
        activeTouch = touch
        base.removeAllActions()
        base.alpha = 1
        base.position = touch.location(in: parent)
        touchActive(touch: touch)
    }
    
    public func touchEndedOrCancelled(touch: UITouch) {
        guard touch === activeTouch else { return }
        activeTouch = nil
        base.run(.fadeOut(withDuration: 0.3))
        delegates.map { $0.joystickEnded(side) }
    }
    
    public func touchMoved(touch: UITouch) {
        guard touch === activeTouch else { return }
        touchActive(touch: touch)
    }
    
    public func update() {
        guard let touch = activeTouch else { return }
        touchActive(touch: touch)
    }
}
