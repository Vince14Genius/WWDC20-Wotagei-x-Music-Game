@_exported import SideKit

public protocol JoystickInputDelegate {
    func joystickMoved(_ side: Side, newMagnitude: Double, newDirection: Double)
    func joystickEnded(_ side: Side)
}
