public enum Side: Character {
    case left = "L"
    case right = "R"
}
