enum TapResult: Double {
    case perfect = 1.0
    case safe = 0.5
    case miss = 0.0
}
