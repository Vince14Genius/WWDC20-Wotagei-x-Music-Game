import SpriteKit
import WotageiShared

class ChartTapEffect {
    
    private static let _perfectEmitter = SKEmitterNode(fileNamed: "perfect-emitter")
    
    public static var perfectEmitter: SKEmitterNode? {
        return SKEmitterNode.copy(_perfectEmitter)
    }
    
    private let node = SKLabelNode()
    private let fontSize: CGFloat = 24
    private let fontName = "HelveticaNeueBold"
    
    private var emitter: SKEmitterNode?
    
    public init(text: String, color: UIColor, emitter: SKEmitterNode?, parent: SKNode, position: CGPoint) {
        parent.addChild(node)
        self.emitter = emitter
        if let e = emitter { node.addChild(e) }
        node.text = text
        node.fontColor = color
        node.fontSize = fontSize / 2 + fontSize / 2 / CGFloat(text.count)
        node.fontName = fontName
        node.position = position
        run(delay: 0.2)
    }
    
    /**
     Plays effect, then self-destructs
     */
    private func run(delay: TimeInterval) {
        let decayDuration = abs(Double(emitter?.particleAlpha ?? 0.1) / Double(emitter?.particleAlphaSpeed ?? 1))
        node.run(.sequence([
            .fadeIn(withDuration: delay),
            .run { self.emitter?.particleBirthRate = 0 },
            .wait(forDuration: decayDuration),
            .fadeOut(withDuration: delay),
            .removeFromParent()
        ]))
    }
}
