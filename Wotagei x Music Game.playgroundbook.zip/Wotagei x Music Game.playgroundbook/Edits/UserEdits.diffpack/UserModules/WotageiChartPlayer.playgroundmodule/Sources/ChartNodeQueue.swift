import Foundation
import GameMathKit
import WotageiChart
import WotageiShared

struct ChartNodeQueue {
    private var array = [ChartNode]()
    public var nodeArray: [ChartNode] { return array }
    
    /**
     - return: true if successful, false if not
     */
    public mutating func push(_ node: ChartNode) -> Bool {
        // Test if node already exists
        guard !array.contains(where: { $0.data == node.data }) else {
            return false
        }
        
        array.append(node)
        return true
    }
    
    public mutating func pop() -> ChartNode {
        return array.remove(at: 0)
    }
    
    public func peek() -> ChartNode? {
        return array.first
    }
    
    public func tap(side: Side, location: CGPoint, currentTime: TimeInterval) -> [TapResult] {
        let tapCandidates = array.filter { 
            let isOnCorrectSide = side == $0.data.side
            let isWithinRange = abs($0.position - location) <= Double(ChartNode.nodeRadius) * 1.5
            let isAfterTime = currentTime >= WotageiConstants.time(from: $0.data.beatID) - ChartPlayer.halfPerfectWindow
            return isOnCorrectSide && isWithinRange && isAfterTime
        }.sorted {
            $0.data.beatID < $1.data.beatID
        }
        
        return tapCandidates.map { $0.tap(currentTime: currentTime) }
    }
    
    public mutating func cleanup(before timeThreshold: TimeInterval) {
        array = array.filter {
            WotageiConstants.time(from: $0.data.beatID) > timeThreshold
        }
    }
}

