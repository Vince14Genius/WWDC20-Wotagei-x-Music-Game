import UIKit
import JoystickKit
import GameMathKit
import WotageiChart
import WotageiShared

public class ChartPlayer: JoystickInputDelegate {
    
    public static var perfectWindow: TimeInterval {
        switch WotageiSettings.difficulty {
        case .easy:
            return 0.75
        case .medium:
            return 0.5
        case .hard:
            return 0.25
        }
        
    }
    public static var halfPerfectWindow: TimeInterval { return perfectWindow / 2 }
    public static var fullWindow: TimeInterval { return perfectWindow * 2 }
    public static var halfFullWindow: TimeInterval { return halfPerfectWindow * 2 }
    
    private var elapsedTime: TimeInterval = 0.0
    private var startTime: TimeInterval = 0.0
    private var playerTime: TimeInterval {
        return elapsedTime - startTime - WotageiConstants.startingWait
    }
    
    private let layerNode = SKNode()
    private let visualAidPaths = [
        Side.left: SKShapeNode(),
        Side.right: SKShapeNode()
    ]
    
    private let chartTable: ChartTable
    private var chartNodes = ChartNodeQueue()
    
    public init(chart: ChartTable, parent: SKNode, position: CGPoint) {
        chartTable = chart
        layerNode.position = position
        layerNode.zPosition = WotageiConstants.nodeZ
        parent.addChild(layerNode)
        
        // Set up paths
        visualAidPaths.map { (key, value) in
            value.lineWidth = 32
            value.strokeColor = ChartNode.nodeColor(side: key).modifiedTo(r: nil, g: nil, b: nil, a: 0.25) ?? #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.25) // alpha = 0.25
            layerNode.addChild(value)
            
            // Gradient shader
            let r = Float(value.strokeColor.red ?? 1)
            let g = Float(value.strokeColor.green ?? 1)
            let b = Float(value.strokeColor.blue ?? 1)
            value.strokeShader = SKShader(source: 
                """
                void main() {
                    float norm_pos = v_path_distance / u_path_length; 
                    vec4 d_s = SKDefaultShading();
                    if ( norm_pos <= 0.7f ) {
                        float mult = norm_pos / 0.7f;
                        gl_FragColor = vec4(d_s.r * mult, d_s.g * mult, d_s.b * mult, d_s.a);
                    } else {
                        float mult = (1 - norm_pos) / 0.3f;
                        gl_FragColor = vec4(d_s.r * mult, d_s.g * mult, d_s.b * mult, d_s.a);
                    }
                }
                """
            )
        }
    }
    
    public func update(currentTime: TimeInterval) {
        elapsedTime = currentTime
        if startTime == 0 {
            startTime = currentTime
        }
        
        // Clean up chartNodes
        
        let threshold = playerTime - 3 * Self.perfectWindow
        chartNodes.cleanup(before: threshold)
        
        // Add new chartNodes
        
        chartTable.findRows(timeRange: 
            (playerTime - Self.halfFullWindow)..<(playerTime + Self.halfFullWindow)
        ).map {
            let chartNode = ChartNode(data: $0)
            if chartNodes.push(chartNode) {
                chartNode.activate(parent: layerNode, currentTime: playerTime)
            }
        }
        
        // Update Bezier curve
        visualAidPaths.map { (key, value) in
            value.path = computePath(for: key)
        }
    }
    
    // MARK: - JoystickInputDelegate methods
    
    public func joystickMoved(_ side: Side, newMagnitude: Double, newDirection: Double) {
        let newLocation = pointified(magnitude: newMagnitude * WotageiConstants.wingspan, direction: newDirection)
        chartNodes.tap(side: side, location: newLocation, currentTime: playerTime)
        
        // Mirror
        layerNode.xScale = WotageiSettings.isMirrored ? -1 : 1
    }
    
    public func joystickEnded(_ side: Side) {}
    
    // MARK: - Supporting methods
    
    private func computePath(for side: Side) -> CGPath { 
        let granularity = 10
        
        var points = chartNodes.nodeArray.filter { $0.data.side == side }.map { $0.position }
        
        if points.count == 0 { return bezierPath(for: side) }
        
        while points.count < 4 {
            points.insert(points[0], at: 0)
            points.append(points[points.count - 1])
        }
        
        // Add control points
        points.insert(points[0], at: 0)
        points.append(points[points.count - 1])
        
        let smoothedPath = UIBezierPath()
        smoothedPath.move(to: points[0])
        
        for i in 1 ..< points.count - 2 {
            let p0 = points[i - 1]
            let p1 = points[i]
            let p2 = points[i + 1]
            let p3 = points[i + 2]
            
            // Use Catmull-Rom splines
            for i in 1 ..< granularity {
                let t = CGFloat(i) * (1 / CGFloat(granularity))
                let tt = t * t
                let ttt = tt * t
                
                let x = 0.5 * (2*p1.x+(p2.x-p0.x)*t + (2*p0.x-5*p1.x+4*p2.x-p3.x)*tt + (3*p1.x-p0.x-3*p2.x+p3.x)*ttt)
                let y = 0.5 * (2*p1.y+(p2.y-p0.y)*t + (2*p0.y-5*p1.y+4*p2.y-p3.y)*tt + (3*p1.y-p0.y-3*p2.y+p3.y)*ttt)
                
                smoothedPath.addLine(to: CGPoint(x: x, y: y))
            }
            
            smoothedPath.addLine(to: p2)
        }
        
        smoothedPath.addLine(to: points[points.count - 1])
        return smoothedPath.cgPath
    }
    
    private func bezierPath(for side: Side) -> CGPath {
        let points = chartNodes.nodeArray.filter { $0.data.side == side }.map { $0.position }
        let bezierPath = UIBezierPath()
        var previousPoint: CGPoint?
        var isFirst = true
        
        points.map { point in
            defer { previousPoint = point }
            guard let prevPoint = previousPoint else {
                bezierPath.move(to: point)
                return
            }
            let midPoint = (point + prevPoint) * 0.5
            if isFirst {
                bezierPath.addLine(to: midPoint)
                isFirst = false
            } else {
                bezierPath.addQuadCurve(to: midPoint, controlPoint: prevPoint)
            }
        }
        
        if let prevPoint = previousPoint {
            bezierPath.addLine(to: prevPoint)
        }
        
        return bezierPath.cgPath
    }
}

