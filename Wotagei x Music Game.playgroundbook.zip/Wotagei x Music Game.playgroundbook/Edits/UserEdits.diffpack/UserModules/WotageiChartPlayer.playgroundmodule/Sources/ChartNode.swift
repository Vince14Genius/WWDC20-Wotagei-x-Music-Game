import SpriteKit
import GameMathKit
import WotageiShared
import WotageiChart

class ChartNode {
    
    public static let nodeRadius: CGFloat = 40
    
    private let fontName = "Avenir"
    private let fontSize: CGFloat = 20
    
    private let node = SKNode()
    private let innerCircle = SKShapeNode(circleOfRadius: ChartNode.nodeRadius / 2)
    private let outerCircle = SKShapeNode(circleOfRadius: ChartNode.nodeRadius * 2)
    
    public let data: ChartRow
    public var position: CGPoint { return node.position }
    
    private func setRadius(_ radius: CGFloat, `for` circleNode: SKShapeNode) {
        circleNode.path = CGPath(ellipseIn: CGRect(
            x: -radius, y: -radius, width: 2 * radius, height: 2 * radius
        ), transform: nil)
    }
    
    public static func nodeColor(side: Side) -> UIColor {
        let baseColor: UIColor
        switch side {
        case .left:
            baseColor = WotageiSettings.leftGlowstickColor
        case .right:
            baseColor = WotageiSettings.rightGlowstickColor
        }
        return baseColor.modifiedTo(r: nil, g: nil, b: nil, a: 0.5) ?? #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.5) // alpha = 0.5
    }
    
    private func makeEffect(tapResult: TapResult) {
        let text: String
        let color: UIColor
        var emitter: SKEmitterNode?
        
        switch tapResult {
        case .perfect:
            text = "PERFECT" 
            color = #colorLiteral(red: 1.0, green: 1.0, blue: 0.75, alpha: 1.0)
            emitter = ChartTapEffect.perfectEmitter
        case .safe:
            text = "SAFE" 
            color = #colorLiteral(red: 0.5568627450980392, green: 0.35294117647058826, blue: 0.9686274509803922, alpha: 1.0)
        case .miss:
            text = "MISS"
            color = #colorLiteral(red: 0.5725490196078431, green: 0.0, blue: 0.23137254901960785, alpha: 1.0)
        }
        
        ChartTapEffect(
            text: text,
            color: color,
            emitter: emitter, 
            parent: node.parent ?? node, 
            position: node.position
        )
    }
    
    private func miss() {
        makeEffect(tapResult: .miss)
    }
    
    public init(data: ChartRow) {
        self.data = data
        node.position = pointified(
            magnitude: data.magnitude * WotageiConstants.wingspan, 
            direction: data.direction
        )
        node.addChild(innerCircle)
        node.addChild(outerCircle)
        innerCircle.fillColor = Self.nodeColor(side: data.side)
        
        // Show label
        let labelNode = SKLabelNode(text: String(data.side.rawValue))
        innerCircle.addChild(labelNode)
        labelNode.zPosition = 1
        labelNode.fontName = fontName
        labelNode.fontSize = fontSize
        labelNode.alpha = 0.25
        labelNode.verticalAlignmentMode = .center
    }
    
    public func activate(parent: SKNode, currentTime: TimeInterval) {
        parent.addChild(node)
        
        // Play default animation (until "miss")
        let dataTime = WotageiConstants.time(from: data.beatID)
        let halfTime = ChartPlayer.halfFullWindow
        let iwRaw = dataTime - halfTime - currentTime
        let initialWait = iwRaw > 0 ? iwRaw : 0
        let firstHalfRemainingTime = dataTime - currentTime
        let firstHalf = firstHalfRemainingTime < halfTime ? firstHalfRemainingTime : halfTime
        
        node.run(.sequence([
            .hide(),
            .wait(forDuration: initialWait),
            .unhide(),
            .customAction(withDuration: firstHalf) { node, elapsedTime in 
                let timeMultiplier = elapsedTime / CGFloat(halfTime)
                let innerDelta = timeMultiplier
                let outerDelta = timeMultiplier * Self.nodeRadius
                
                self.innerCircle.setScale(1 + innerDelta)
                self.innerCircle.alpha = timeMultiplier
                
                self.setRadius(Self.nodeRadius * 2 - outerDelta, for: self.outerCircle)
                self.outerCircle.alpha = timeMultiplier
                
                if timeMultiplier < 0.5 {
                    self.innerCircle.strokeColor = #colorLiteral(red: 0.75, green: 0.75, blue: 0.75, alpha: 0.75) // alpha = 0.5
                    self.outerCircle.strokeColor = #colorLiteral(red: 0.75, green: 0.75, blue: 0.75, alpha: 0.5) // alpha = 0.5
                } else {
                    self.innerCircle.strokeColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.75) // alpha = 0.75
                    self.outerCircle.strokeColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.75) // alpha = 0.75
                }
            },
            .customAction(withDuration: halfTime) { node, elapsedTime in 
                let timeMultiplier = elapsedTime / CGFloat(halfTime)
                let innerDelta = timeMultiplier
                let outerDelta = timeMultiplier * Self.nodeRadius
                
                self.innerCircle.setScale(2 - innerDelta)
                self.innerCircle.alpha = 1 - timeMultiplier
                
                self.setRadius(Self.nodeRadius + outerDelta, for: self.outerCircle)
                self.node.alpha = 1 - timeMultiplier
                
                if timeMultiplier < 0.5 {
                    self.innerCircle.strokeColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.75) // alpha = 0.75
                    self.outerCircle.strokeColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.75) // alpha = 0.75
                } else {
                    self.innerCircle.strokeColor = #colorLiteral(red: 0.75, green: 0.75, blue: 0.75, alpha: 0.75) // alpha = 0.5
                    self.outerCircle.strokeColor = #colorLiteral(red: 0.75, green: 0.75, blue: 0.75, alpha: 0.5) // alpha = 0.5
                }
            },
            .run { self.miss() },
            .removeFromParent()
        ]))
    }
    
    public func tap(currentTime: TimeInterval) -> TapResult {
        let deltaTime = abs(WotageiConstants.time(from: data.beatID) - currentTime)
        let halfWindow = ChartPlayer.halfPerfectWindow
        
        defer {
            node.removeAllActions()
            node.removeFromParent()
        }
        
        if (0...halfWindow).contains(deltaTime) {
            // "Perfect"
            makeEffect(tapResult: .perfect)
            return .perfect
        } else if (halfWindow...halfWindow * 3).contains(deltaTime) {
            // "Safe"
            makeEffect(tapResult: .safe)
            return .safe
        } else {
            // "Miss"
            miss()
            return .miss
        }
    }
    
}
