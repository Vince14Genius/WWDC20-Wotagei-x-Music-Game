// ロマンス警報 + ロマンス

import WotageiChart

public extension GameCharts {
    public static let romansu = ChartTable([
    
    ])
}
