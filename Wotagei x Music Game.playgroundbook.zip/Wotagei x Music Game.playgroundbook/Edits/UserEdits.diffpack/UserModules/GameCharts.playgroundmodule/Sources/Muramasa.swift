// ムラマサ

import WotageiChart

public extension GameCharts {
    public static let muramasa = ChartTable([
        
    ])
}
