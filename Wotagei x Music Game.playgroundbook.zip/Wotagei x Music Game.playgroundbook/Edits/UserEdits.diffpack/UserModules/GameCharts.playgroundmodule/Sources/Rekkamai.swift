// 烈火舞

import WotageiChart

public extension GameCharts {
    public static let rekkamai = ChartTable([
        
    ])
}
