import WotageiChart

public struct GameCharts {}

