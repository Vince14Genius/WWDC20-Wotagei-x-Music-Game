// 桜華

import WotageiChart

public extension GameCharts {
    public static let ouka = ChartTable([
        
    ])
}
