// ロザリオ + ロサンゼルス

import WotageiChart

public extension GameCharts {
    public static let rosario = ChartTable([
        
    ])
}
