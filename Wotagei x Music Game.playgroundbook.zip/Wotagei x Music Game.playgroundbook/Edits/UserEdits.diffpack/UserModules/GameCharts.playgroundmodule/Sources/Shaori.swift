// シャオリー

import WotageiChart

public extension GameCharts {
    public static let shaori = ChartTable([
        
    ])
}
