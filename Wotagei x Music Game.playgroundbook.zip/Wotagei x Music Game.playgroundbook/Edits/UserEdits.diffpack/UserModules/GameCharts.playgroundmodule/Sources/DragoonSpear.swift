// 旧ドラグーンスピア

import WotageiChart

public extension GameCharts {
    public static let dragoonSpear = ChartTable([
        
    ])
}

