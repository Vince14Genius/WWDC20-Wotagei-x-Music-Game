// 関西OAD + ニーハイオーハイ + ソイヤ

import WotageiChart

public extension GameCharts {
    public static let oad = ChartTable([
        // 0
        (0.0, .right, 0.57, CT.rad(70), nil),
        (0.0, .left, 0.57, CT.rad(110), nil),
        
        // 1
        (0.1, .right, 0.75, CT.rad(70), nil),
        (0.3, .right, 0.80, CT.rad(28), nil),
        (0.6, .right, 0.80, CT.rad(0), nil),
        (0.9, .right, 0.42, CT.rad(-60), nil),
        (1.1, .right, 0.31, CT.rad(-128), nil),
        (1.4, .right, 0.37, CT.rad(166), nil),
        (1.8, .right, 0.51, CT.rad(86), nil),
        (2.0, .right, 0.70, CT.rad(35), nil),
        
        (0.1, .left, 0.61, CT.rad(90), nil),
        (0.3, .left, 0.34, CT.rad(59), nil),
        (0.6, .left, 0.10, CT.rad(-90), nil),
        (0.9, .left, 0.45, CT.rad(-160), nil),
        (1.1, .left, 0.64, CT.rad(150), nil),
        (1.4, .left, 0.70, CT.rad(90), nil),
        (1.8, .left, 0.75, CT.rad(58), nil),
        (2.0, .left, 0.70, CT.rad(40), nil),
        
        // 2
        (2.4, .right, 0.65, CT.rad(53), nil),
        (2.6, .right, 0.58, CT.rad(83), nil),
        (2.8, .right, 0.51, CT.rad(157), nil),
        (3.0, .right, 0.31, CT.rad(-112), nil),
        (3.2, .right, 0.55, CT.rad(-16), nil),
        (3.4, .right, 0.68, CT.rad(37), nil),
        (3.6, .right, 0.74, CT.rad(85), nil),
        (3.8, .right, 0.75, CT.rad(123), nil),
        (4.0, .right, 0.70, CT.rad(140), nil),
        
        (2.4, .left, 0.68, CT.rad(51), nil),
        (2.6, .left, 0.65, CT.rad(77), nil),
        (2.8, .left, 0.74, CT.rad(124), nil),
        (3.0, .left, 0.71, CT.rad(158), nil),
        (3.2, .left, 0.55, CT.rad(-164), nil),
        (3.4, .left, 0.31, CT.rad(-88), nil),
        (3.6, .left, 0.29, CT.rad(7), nil),
        (3.8, .left, 0.52, CT.rad(95), nil),
        (4.0, .left, 0.70, CT.rad(145), nil),
        
        // 3
        (4.4, .right, 0.68, CT.rad(180-51), nil),
        (4.6, .right, 0.65, CT.rad(180-77), nil),
        (4.8, .right, 0.74, CT.rad(180-124), nil),
        (5.0, .right, 0.71, CT.rad(180-158), nil),
        (5.2, .right, 0.55, CT.rad(-180+164), nil),
        (5.4, .right, 0.31, CT.rad(-180+88), nil),
        (5.6, .right, 0.29, CT.rad(180-7), nil),
        (5.8, .right, 0.52, CT.rad(180-95), nil),
        (6.0, .right, 0.70, CT.rad(180-145), nil),
        
        (4.4, .left, 0.65, CT.rad(180-53), nil),
        (4.6, .left, 0.58, CT.rad(180-83), nil),
        (4.8, .left, 0.51, CT.rad(180-157), nil),
        (5.0, .left, 0.31, CT.rad(-180+112), nil),
        (5.2, .left, 0.55, CT.rad(-180+16), nil),
        (5.4, .left, 0.68, CT.rad(180-37), nil),
        (5.6, .left, 0.74, CT.rad(180-85), nil),
        (5.8, .left, 0.75, CT.rad(180-123), nil),
        (6.0, .left, 0.70, CT.rad(180-140), nil),
        
        // 4
        (6.4, .right, 0.65, CT.rad(53), nil),
        (6.6, .right, 0.58, CT.rad(83), nil),
        (6.8, .right, 0.51, CT.rad(157), nil),
        (7.0, .right, 0.31, CT.rad(-112), nil),
        (7.2, .right, 0.55, CT.rad(-16), nil),
        (7.4, .right, 0.68, CT.rad(37), nil),
        (7.6, .right, 0.74, CT.rad(85), nil),
        (7.8, .right, 0.75, CT.rad(123), nil),
        (8.0, .right, 0.70, CT.rad(140), nil),
        
        (6.4, .left, 0.68, CT.rad(51), nil),
        (6.6, .left, 0.65, CT.rad(77), nil),
        (6.8, .left, 0.74, CT.rad(124), nil),
        (7.0, .left, 0.71, CT.rad(158), nil),
        (7.2, .left, 0.55, CT.rad(-164), nil),
        (7.4, .left, 0.31, CT.rad(-88), nil),
        (7.6, .left, 0.29, CT.rad(7), nil),
        (7.8, .left, 0.52, CT.rad(95), nil),
        (8.0, .left, 0.70, CT.rad(145), nil),
        
        // 5
        (8.4, .right, 0.68, CT.rad(180-51), nil),
        (8.6, .right, 0.65, CT.rad(180-77), nil),
        (8.8, .right, 0.74, CT.rad(180-124), nil),
        (9.0, .right, 0.71, CT.rad(180-158), nil),
        (9.2, .right, 0.55, CT.rad(-180+164), nil),
        (9.4, .right, 0.31, CT.rad(-180+88), nil),
        (9.6, .right, 0.29, CT.rad(180-7), nil),
        (9.8, .right, 0.52, CT.rad(180-95), nil),
        (10.0, .right, 0.70, CT.rad(180-145), nil),
        
        (8.4, .left, 0.65, CT.rad(180-53), nil),
        (8.6, .left, 0.58, CT.rad(180-83), nil),
        (8.8, .left, 0.51, CT.rad(180-157), nil),
        (9.0, .left, 0.31, CT.rad(-180+112), nil),
        (9.2, .left, 0.55, CT.rad(-180+16), nil),
        (9.4, .left, 0.68, CT.rad(180-37), nil),
        (9.6, .left, 0.74, CT.rad(180-85), nil),
        (9.8, .left, 0.75, CT.rad(180-123), nil),
        (10.0, .left, 0.70, CT.rad(180-140), nil),
        
        // 6
        (10.4, .right, 0.65, CT.rad(53), nil),
        (10.6, .right, 0.58, CT.rad(83), nil),
        (10.8, .right, 0.51, CT.rad(157), nil),
        (10.0, .right, 0.31, CT.rad(-112), nil),
        (11.2, .right, 0.55, CT.rad(-16), nil),
        (11.4, .right, 0.68, CT.rad(37), nil),
        (11.6, .right, 0.74, CT.rad(85), nil),
        (11.8, .right, 0.75, CT.rad(123), nil),
        (12.0, .right, 0.70, CT.rad(140), nil),
        
        (10.4, .left, 0.68, CT.rad(51), nil),
        (10.6, .left, 0.65, CT.rad(77), nil),
        (10.8, .left, 0.74, CT.rad(124), nil),
        (11.0, .left, 0.71, CT.rad(158), nil),
        (11.2, .left, 0.55, CT.rad(-164), nil),
        (11.4, .left, 0.31, CT.rad(-88), nil),
        (11.6, .left, 0.29, CT.rad(7), nil),
        (11.8, .left, 0.52, CT.rad(95), nil),
        (12.0, .left, 0.70, CT.rad(145), nil),
        
    ])
}

