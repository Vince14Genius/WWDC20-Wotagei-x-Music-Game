// アマテラス改

import WotageiChart

public extension GameCharts {
    public static let amaterasu = ChartTable([
        
    ])
}

